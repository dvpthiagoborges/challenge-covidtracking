﻿using BoxTI.Challenge.CovidTracking.Models.Entities;
using BoxTI.Challenge.CovidTracking.Models.ImportExport.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace BoxTI.Challenge.CovidTracking.Models.ImportExport.Services
{
    public class ImportExportService : FileResult
    {
        private readonly InfoCovid _infoCovid;

        public ImportExportService(InfoCovid infoCovid, string fileName) : base("text/csv")
        {
            _infoCovid = infoCovid;
            FileDownloadName = fileName;
        }

        public override async Task ExecuteResultAsync(ActionContext context)
        {
            var response = context.HttpContext.Response;
            context.HttpContext.Response.Headers.Add("Content-Disposition", new[] { "attachment; filename=" + FileDownloadName });
            using (var streamWriter = new StreamWriter(response.Body))
            {
                await streamWriter.WriteLineAsync(
                  $"Id, ActiveCases, Country, LastUpdate, NewCases, NewDeaths, TotalCases, TotalDeaths, TotalRecovered, Active"
                );

                await streamWriter.WriteLineAsync(
                  $"{_infoCovid.Id}, {_infoCovid.ActiveCases}, {_infoCovid.Country}, {_infoCovid.LastUpdate}, {_infoCovid.NewCases}, {_infoCovid.NewDeaths}, {_infoCovid.TotalCases}, {_infoCovid.TotalDeaths}, {_infoCovid.TotalRecovered}, {_infoCovid.Active}"
                );

                await streamWriter.FlushAsync();
            }
        }

        //public async Task<IEnumerable<InfoCovid>> ExportFileCSV(IEnumerable<InfoCovid> infoCovidViewModel)
        //{
        //    var response = context.HttpContext.Response;
        //    context.HttpContext.Response.Headers.Add("Content-Disposition", new[] { "attachment; filename=" + FileDownloadName });
        //    using (var streamWriter = new StreamWriter(response.Body))
        //    {
        //        await streamWriter.WriteLineAsync(
        //          $"Id, ActiveCases, Country, LastUpdate, NewCases, NewDeaths, TotalCases, TotalDeaths, TotalRecovered, Active"
        //        );
        //        foreach (var p in _infoCovid)
        //        {
        //            await streamWriter.WriteLineAsync(
        //              $"{p.Id}, {p.ActiveCases}, {p.Country}, {p.LastUpdate}, {p.NewCases}, {p.NewDeaths}, {p.TotalCases}, {p.TotalDeaths}, {p.TotalRecovered}, {p.Active}"
        //            );
        //            await streamWriter.FlushAsync();
        //        }
        //        await streamWriter.FlushAsync();
        //    }

        //    return infoCovidViewModel;
        //}
    }
}
