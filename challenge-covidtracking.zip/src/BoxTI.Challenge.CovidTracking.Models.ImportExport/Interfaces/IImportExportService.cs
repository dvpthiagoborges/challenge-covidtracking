﻿using BoxTI.Challenge.CovidTracking.Models.Entities;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace BoxTI.Challenge.CovidTracking.Models.ImportExport.Interfaces
{
    public interface IImportExportService
    {
        Task<IEnumerable<InfoCovid>> ExportFileCSV(IEnumerable<InfoCovid> infoCovidViewModel);
    }
}
