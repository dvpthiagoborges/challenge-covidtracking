﻿namespace BoxTI.Challenge.CovidTracking.CrossCutting.Identity.Models.AccountViewModels
{
    public class UserRegisteredViewModel
    {
        public string Name { get; set; }
        public string Email { get; set; }
    }
}
