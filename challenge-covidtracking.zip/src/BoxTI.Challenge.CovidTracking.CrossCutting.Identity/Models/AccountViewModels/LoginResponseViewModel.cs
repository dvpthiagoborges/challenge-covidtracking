﻿namespace BoxTI.Challenge.CovidTracking.CrossCutting.Identity.Models.AccountViewModels
{
    public class LoginResponseViewModel
    {
        public string AccessToken { get; set; }
    }
}
