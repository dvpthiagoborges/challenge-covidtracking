﻿namespace BoxTI.Challenge.CovidTracking.ExternalData.Base
{
    public class ExternalDataSettings
    {
        public static string Key { get; set; }
        public static string Host { get; set; }
        public static string Url { get; set; }
    }
}
